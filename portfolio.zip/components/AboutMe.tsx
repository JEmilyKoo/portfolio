import { FaGithub, FaEnvelope, FaBlogger, FaPhone } from 'react-icons/fa';
import Image from 'next/image';

export default function AboutMe() {
  return (
    <section
      id="about"
      className="max-w-[900px] mx-auto mb-24 pt-12 px-4 flex flex-col items-center"
    >
      <Image
        src="/images/picture.jpg"
        alt="구정은 프로필"
        width={128}
        height={128}
        className="w-[128px] h-[128px] rounded-full object-cover mb-6 shadow-lg border-4 border-surface dark:border-neutral-800"
      />
      <h2 className="text-3xl md:text-4xl font-extrabold mb-1 text-center">
        구정은 <span className="text-primary dark:text-blue-400">Emily Koo</span>
      </h2>
      <div className="text-lg text-subText dark:text-gray-300 font-semibold mb-4 text-center">실무형 프론트엔드 개발자</div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-3xl">
        <div className="bg-surface dark:bg-neutral-800 rounded-2xl p-6 shadow-custom border border-border dark:border-neutral-700">
          <h3 className="text-xl font-bold text-primary dark:text-blue-400 mb-4">핵심 역량</h3>
          <ul className="space-y-3">
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">React/TypeScript</span> 기반 SPA 개발
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">디자인 시스템</span> 구축 및 운영
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">성능 최적화</span> 및 UX 개선
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">글로벌 협업</span> (일본어/영어)
              </span>
            </li>
          </ul>
        </div>

        <div className="bg-surface dark:bg-neutral-800 rounded-2xl p-6 shadow-custom border border-border dark:border-neutral-700">
          <h3 className="text-xl font-bold text-primary dark:text-blue-400 mb-4">경력 사항</h3>
          <ul className="space-y-3">
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">3년차</span> 프론트엔드 개발자
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">㈜가온아이</span> 실무 경험
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">SSAFY</span> 수료
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-accent dark:text-teal-400">•</span>
              <span className="text-text dark:text-gray-200">
                <span className="font-semibold text-primary dark:text-blue-400">SQLD</span> 자격증 보유
              </span>
            </li>
          </ul>
        </div>
      </div>

      <div className="flex gap-4 mt-8">
        <a
          href="https://github.com/JEmilyKoo"
          target="_blank"
          aria-label="GitHub"
          className="text-primary dark:text-blue-400 text-[1.7rem] transition-colors duration-200 hover:text-accent dark:hover:text-teal-400 focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <FaGithub />
        </a>
        <a
          href="mailto:jemilykoo@gmail.com"
          aria-label="Email"
          className="text-primary dark:text-blue-400 text-[1.7rem] transition-colors duration-200 hover:text-accent dark:hover:text-teal-400 focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <FaEnvelope />
        </a>
        <a
          href="https://velog.io/@jemilykoo/posts"
          target="_blank"
          aria-label="Blog"
          className="text-primary dark:text-blue-400 text-[1.7rem] transition-colors duration-200 hover:text-accent dark:hover:text-teal-400 focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <FaBlogger />
        </a>
        <a
          href="tel:01025815680"
          aria-label="Phone"
          className="text-primary dark:text-blue-400 text-[1.7rem] transition-colors duration-200 hover:text-accent dark:hover:text-teal-400 focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <FaPhone />
        </a>
      </div>
    </section>
  );
} 