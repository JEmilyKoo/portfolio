export interface Project {
  title: string;
  period: string;
  role: string;
  description: string;
  problem: string;
  solution: string;
  result: string;
  metrics?: string[]; // 성과 수치
  tags?: string[]; // 기술/협업/AI/테스트 등
  github?: string;
  demo?: string;
  ai?: boolean;
  video?: string;
  image?: string[];
}

export default function ProjectCard({
  title,
  period,
  role,
  description,
  problem,
  solution,
  result,
  metrics,
  tags,
  github,
  demo,
  ai,
  video,
  image,
}: Project) {
  return (
    <article className="bg-surface dark:bg-neutral-800 border border-border dark:border-neutral-700 rounded-2xl shadow-custom px-8 py-8 mb-16 max-w-[900px] mx-auto flex flex-col gap-8 transition hover:scale-[1.01] hover:shadow-lg">
      <div className="flex flex-wrap items-center gap-3 mb-2">
        <h2 className="text-2xl md:text-3xl font-extrabold text-text dark:text-white m-0">
          {title}
        </h2>
        {ai && (
          <span className="bg-accent/10 text-accent dark:bg-teal-400/10 dark:text-teal-400 text-xs font-bold rounded px-2 py-0.5 ml-1 border border-accent/30">AI</span>
        )}
        <span className="ml-auto text-sm text-subText dark:text-gray-400 font-mono">{period}</span>
        <span className="text-sm text-primary dark:text-blue-400 font-semibold ml-2">{role}</span>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="flex flex-col gap-4">
          <p className="text-base text-subText dark:text-gray-300 m-0 font-semibold">{description}</p>
          
          <div className="flex flex-wrap gap-2 mb-2">
            {metrics.map((m, i) => (
              <span key={i} className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 font-bold rounded-full px-4 py-1 text-sm border border-blue-200 dark:border-blue-800">
                {m}
              </span>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-background dark:bg-neutral-900 rounded-xl p-4 border border-border/50 dark:border-neutral-700/50">
              <div className="text-xs font-bold text-primary dark:text-blue-400 mb-1 tracking-widest uppercase">문제</div>
              <div className="text-text dark:text-gray-200 text-sm whitespace-pre-line">{problem}</div>
            </div>
            <div className="bg-background dark:bg-neutral-900 rounded-xl p-4 border border-border/50 dark:border-neutral-700/50">
              <div className="text-xs font-bold text-primary dark:text-blue-400 mb-1 tracking-widest uppercase">구조 설계</div>
              <div className="text-text dark:text-gray-200 text-sm whitespace-pre-line">{solution}</div>
            </div>
            <div className="bg-background dark:bg-neutral-900 rounded-xl p-4 border border-border/50 dark:border-neutral-700/50">
              <div className="text-xs font-bold text-primary dark:text-blue-400 mb-1 tracking-widest uppercase">성과</div>
              <div className="text-text dark:text-gray-200 text-sm whitespace-pre-line">{result}</div>
            </div>
          </div>

          {tags && tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2">
              {tags.map((t, i) => (
                <span key={i} className="bg-border dark:bg-neutral-700 text-subText dark:text-gray-300 rounded-full px-3 py-1 text-xs font-semibold border border-border/40 dark:border-neutral-600">
                  {t}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-col gap-4">
          {image && image.length > 0 && (
            <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg">
              <img
                src={image[0]}
                alt={`${title} 프로젝트 이미지`}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          {video && (
            <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg">
              <iframe
                src={video.replace('watch?v=', 'embed/')}
                title={`${title} 프로젝트 영상`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
        </div>
      </div>

      <div className="flex gap-4 mt-2">
        {github && (
          <a
            href={github}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2 rounded-lg border border-primary text-primary dark:border-blue-400 dark:text-blue-400 font-semibold text-base bg-surface dark:bg-neutral-800 shadow-custom transition-all duration-200 hover:bg-primary hover:text-white hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            GitHub
          </a>
        )}
        {demo && (
          <a
            href={demo}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2 rounded-lg border border-accent text-accent dark:border-teal-400 dark:text-teal-400 font-semibold text-base bg-surface dark:bg-neutral-800 shadow-custom transition-all duration-200 hover:bg-accent hover:text-white hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-accent"
          >
            Demo
          </a>
        )}
      </div>
    </article>
  );
} 